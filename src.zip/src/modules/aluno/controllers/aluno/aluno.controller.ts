import { Controller, Get } from '@nestjs/common';

@Controller('aluno')
export class AlunoController {
  @Get()
  obterAlunos(): any {
    return { message: 'Hello, world' };
  }
}
